
public class JavaJDBC {

  public static void main(String[] args) {
    InsertProcedures test = new InsertProcedures();
    // test.insertClient("Jack", "123333", "email@dd.com");
    // test.insertLog("EXT", "clients", 1, "Log Info");

    //test.insertOrder("desc", 555, 1);
    test.insertProduct("banana", 12);
  }

}
