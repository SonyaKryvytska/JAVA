DECLARE
    NAME_PARAM VARCHAR2(100);
    PRICE_PARAM NUMBER;
    v_Return NUMBER;
BEGIN
    NAME_PARAM := 'Pear';
    PRICE_PARAM := 4;
    v_Return := hr.insert_products(
       name =>NAME_PARAM,
        price => PRICE_PARAM
    );
END;
SELECT * FROM HR.PRODUCTS
---------------------------------------------
DECLARE
    NAME_PARAM VARCHAR2(100);
    PHONE_PARAM VARCHAR2(100);
    EMAIL_PARAM VARCHAR2(100);
    v_Return NUMBER;
BEGIN
    NAME_PARAM := 'Sonya';
    PHONE_PARAM := '+849 9438 932';
    EMAIL_PARAM := 'sonta@email.com';
    v_Return := hr.insert_client(
        name_param =>NAME_PARAM,
        phone_param => PHONE_PARAM,
        email_param =>EMAIL_PARAM
    );
END;
SELECT * FROM HR.CLIENTS
-------------hr.insert_my_logs-----------------------------
---action in VARCHAR2,
---tbl_name in VARCHAR2,
----id_row in Number,
----log_info in VARCHAR2,
----log_time in DATE
DECLARE
    ACTION_PARAM VARCHAR2(100);
    TBL_NAME_PARAM VARCHAR2(100);
    ID_ROW_PARAM NUMBER;
    LOG_INFO_PARAM VARCHAR2(100);
    LOG_TIME_PARAM DATE;
    v_Return NUMBER;
BEGIN
    ACTION_PARAM := 'ent';
    TBL_NAME_PARAM := 'prod';
    ID_ROW_PARAM := 0;
    LOG_INFO_PARAM := 'info enter';
    LOG_TIME_PARAM := '24/4/21';
    v_Return := hr.insert_my_logs(
        action =>ACTION_PARAM,
        tbl_name => TBL_NAME_PARAM,
        id_row =>ID_ROW_PARAM,
        log_info =>LOG_INFO_PARAM,
        log_time =>LOG_TIME_PARAM
    );
END;
SELECT * FROM HR.MY_LOGS

------------------------------------------------
----------------hr.insert_orders(
--description in varchar2,
--orders_date in VARCHAR2,
--total_costs in Number,
--clients_id in Number

DECLARE
    DESCRIPTION_PARAM VARCHAR2(100);
    ORDERS_DATE_PARAM VARCHAR2(100);
    TOTAL_COSTS_PARAM NUMBER;
    CLIENTS_PARAM NUMBER;
    v_Return NUMBER;
BEGIN
    DESCRIPTION_PARAM := 'Tasty fruit';
    ORDERS_DATE_PARAM := '24/4/21';
    TOTAL_COSTS_PARAM := 4;
    CLIENTS_PARAM := 1;
    v_Return := hr.insert_orders(
        description =>DESCRIPTION_PARAM,
        orders_date => ORDERS_DATE_PARAM,
        total_costs =>TOTAL_COSTS_PARAM,
        clients_id =>CLIENTS_PARAM
        
    );
END;
SELECT * FROM HR.ORDERS

--------------create or replace function hr.insert_orders_positions(
--orders_id in number,
--products_id in number,
--price in number,
--item_count in number

DECLARE
    ORDERS_ID_PARAM NUMBER;
    PRODUCT_ID_PARAM  NUMBER;
    PRICE_PARAM NUMBER;
    CLIENTS_PARAM NUMBER;
    ITEM_COUNT_PARAM NUMBER;
    v_Return NUMBER;
BEGIN
    ORDERS_ID_PARAM := 1;
    PRODUCT_ID_PARAM := 1;
    PRICE_PARAM := 4;
    CLIENTS_PARAM := 1;
    ITEM_COUNT_PARAM := 1;
    v_Return := hr.insert_orders_positions(
        orders_id =>ORDERS_ID_PARAM,
        products_id => PRODUCT_ID_PARAM,
        price =>PRICE_PARAM,
        item_count =>ITEM_COUNT_PARAM
        
    );
END;
SELECT * FROM HR.ORDERS_POSITIONS
