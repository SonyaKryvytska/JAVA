
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Locale;

public class InsertProcedures {

  Connection connection = null;

  public void insertClient(String name, String phone, String email) {
    try {
      Class.forName("oracle.jdbc.driver.OracleDriver");

      Locale locale = java.util.Locale.getDefault();
      java.util.Locale.setDefault(java.util.Locale.ENGLISH);

      connection = DriverManager.getConnection(
          "jdbc:oracle:thin:@localhost:1521:xe", "SYSTEM",
          "111");

      java.util.Locale.setDefault(locale);

      String call = "DECLARE  NAME_PARAM VARCHAR2(200);  PHONE_PARAM VARCHAR2(200);  EMAIL_PARAM VARCHAR2(200);  v_Return NUMBER;BEGIN  NAME_PARAM := ?;  PHONE_PARAM := ?;  EMAIL_PARAM :=?;  v_Return := exam.INSERT_CLIENT(    NAME_PARAM => NAME_PARAM,    PHONE_PARAM => PHONE_PARAM,    EMAIL_PARAM => EMAIL_PARAM  );END;";

      CallableStatement cstmt = connection.prepareCall(call);
      cstmt.setQueryTimeout(1800);
      cstmt.setString(1, name);
      cstmt.setString(2, phone);
      cstmt.setString(3, email);

      cstmt.executeUpdate();

    } catch (ClassNotFoundException ex) {
      System.out.printf("err", ex.toString());

    } catch (SQLException ex) {
      System.out.printf("err", ex.toString());

    }
  }
//exam.orders_positions_sequence.nextval,orders_id, products_id, price, item_count
  public void insertOrders_positions(Number orders_id, Number products_id, Number price,Number item_count ) {
    try {
      Class.forName("oracle.jdbc.driver.OracleDriver");

      Locale locale = java.util.Locale.getDefault();
      java.util.Locale.setDefault(java.util.Locale.ENGLISH);

      connection = DriverManager.getConnection(
          "jdbc:oracle:thin:@localhost:1521:xe", "SYSTEM",
          "111");

      java.util.Locale.setDefault(locale);

      String call = "DECLARE  ORDERS_ID_PARAM NUMBER; PRODUCT_ID_PARAM  NUMBER; PRICE_PARAM NUMBER; NUMBER;ITEM_COUNT_PARAM NUMBER;  v_Return NUMBER;BEGIN  ORDERS_ID_PARAM := ?;  PRODUCT_ID_PARAM := ?;  PRICE_PARAM :=?; ITEM_COUNT_PARAM :=?; v_Return := exam.INSERT_CLIENT(    ORDERS_ID_PARAM => ORDERS_ID_PARAM,    PRODUCT_ID_PARAM => PRODUCT_ID_PARAM,    PRICE_PARAM => PRICE_PARAM ,     ITEM_COUNT_PARAM => ITEM_COUNT_PARAM );END;";

      CallableStatement cstmt = connection.prepareCall(call);
      cstmt.setQueryTimeout(1800);
      cstmt.setString(1, orders_id);
      cstmt.setString(2, products_id);
      cstmt.setString(3, price);
      cstmt.setString(4, item_count);
      cstmt.executeUpdate();

    } catch (ClassNotFoundException ex) {
      System.out.printf("err", ex.toString());

    } catch (SQLException ex) {
      System.out.printf("err", ex.toString());

    }
  }
  
}
