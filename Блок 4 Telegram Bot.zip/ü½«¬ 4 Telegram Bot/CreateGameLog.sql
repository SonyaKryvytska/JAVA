CREATE TABLE hr.BOT_GAME_LOG
(
  ID INTEGER NOT NULL 
, TIME_DATA VARCHAR2(100 CHAR) NOT NULL 
, MESSAGE_TEXT VARCHAR2(200) NOT NULL 
, CONSTRAINT ID_BOT_GAME_LOG_PK PRIMARY KEY 
  (
    ID 
  )
  ENABLE 
);


Create sequence hr.BOT_GAME_LOG_SEQUENCE
start with 1
increment by 1
minvalue 1
maxvalue 10000;

create or replace function hr.INSERT_BOT_GAME_LOG(
timedata in varchar2,
messagetext in varchar2
)RETURN integer is
nId INTEGER; 
BEGIN
INSERT INTO hr.BOT_GAME_LOG (ID,TIME_DATA,MESSAGE_TEXT) 
values (hr.BOT_GAME_LOG_SEQUENCE.nextval,timedata,messagetext) 
RETURNING ID INTO nId;
return nId;
END;
