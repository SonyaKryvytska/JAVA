Create sequence hr.products_sequence
start with 1
increment by 1
minvalue 1
maxvalue 10000;

CREATE TABLE hr.PRODUCTS
(
  PRODUCTS_ID    INTEGER NOT NULL 
, NAME VARCHAR2(100 CHAR) NOT NULL 
, PRICE Number NOT NULL 
, CONSTRAINT PRODUCTS_PK PRIMARY KEY 
  (
    PRODUCTS_ID 
  )
  ENABLE 
);
-----------------------------------
Create sequence hr.clients_sequence
start with 1
increment by 1
minvalue 1
maxvalue 10000;
CREATE TABLE HR.CLIENTS
(
  CLIENTS_ID INTEGER NOT NULL 
, NAME VARCHAR2(100 CHAR) NOT NULL 
, MAIL VARCHAR2(100 CHAR) NOT NULL 
, PHONE VARCHAR2(20) NOT NULL 
, CONSTRAINT CLIENTS_PK PRIMARY KEY 
  (
    CLIENTS_ID 
  )
  ENABLE 
);
--------------------------
Create sequence hr.my_logs_sequence
start with 1
increment by 1
minvalue 1
maxvalue 10000;
CREATE TABLE HR.MY_LOGS
(
  MY_LOGS_ID INTEGER NOT NULL 
, ACTION NCHAR(3) NOT NULL
, TBL_NAME VARCHAR(50) NOT NULL
, ID_ROW Number NOT NULL
, LOG_INFO VARCHAR(100) NOT NULL
, LOG_TIME DATE NOT NULL
, CONSTRAINT MY_LOGS_PK PRIMARY KEY 
  (
    MY_LOGS_ID
  )
  ENABLE 
);
----------------------
Create sequence hr.orders_sequence
start with 1
increment by 1
minvalue 1
maxvalue 10000;
CREATE TABLE HR.ORDERS
(
  ORDERS_ID INTEGER NOT NULL 
, DESCRIPTION VARCHAR2(100 CHAR) NOT NULL 
, ORDERS_DATE DATE NOT NULL
, TOTAL_COSTS Number NOT NULL
, CLIENT_ID Number NOT NULL
, CONSTRAINT ORDERS_PK PRIMARY KEY 
  (
    ORDERS_ID 
  )
,   CONSTRAINT ORDERS_FK
      FOREIGN KEY (CLIENT_ID)
      REFERENCES hr.CLIENTS(CLIENTS_ID)
  
  ENABLE 
);
----------------------------------
Create sequence hr.orders_positions_sequence
start with 1
increment by 1
minvalue 1
maxvalue 10000;
CREATE TABLE HR.ORDERS_POSITIONS
(
  ORDERS_POSITIONS_ID INTEGER NOT NULL 
, ORDERS_ID Number NOT NULL
, PRODUCTS_ID Number NOT NULL
, PRICE Number NOT NULL
, ITEM_COUNT Number NOT NULL
, CONSTRAINT ORDERS_POSITIONS_PK PRIMARY KEY 
  (
   ORDERS_POSITIONS_ID 
  )
, CONSTRAINT ORDERS_POSITIONS_ORD_FK
    FOREIGN KEY (ORDERS_ID)
    REFERENCES hr.ORDERS(ORDERS_ID)
, CONSTRAINT ORDERS_POSITIONS_PROD_FK
    FOREIGN KEY (PRODUCTS_ID)
    REFERENCES hr.PRODUCTS(PRODUCTS_ID)
  
  ENABLE 
);




