import View.MyWindow;

public class StudentsWindow {
  public static void main(String[] args) {
    MyWindow window = new MyWindow();
    window.setVisible(true);
  }
}
