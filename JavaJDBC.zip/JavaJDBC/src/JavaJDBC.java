

public class JavaJDBC {
    
    public static void main(String[] args) {
        InsertProcedures test = new InsertProcedures();
        test.insertClient("James", "+4839309","email@email.com");
    }
    
}
